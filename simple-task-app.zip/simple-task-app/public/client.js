document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('taskForm');
    const taskInput = document.getElementById('taskInput');
    const taskInputint = document.getElementById('taskInputint');
    const taskList = document.getElementById('taskList');
    const fetchTasksBtn = document.getElementById('fetchTasksBtn');
    const taskTableBody = document.getElementById('taskTableBody');
    const deleteDatabaseBtn = document.getElementById('deleteDatabaseBtn');

    fetchTasksBtn.addEventListener('click', async () => {
        await fetchAndDisplayTasks();
    });

    function createTableRow(task) {
        const row = document.createElement('tr');
        const idCell = document.createElement('td');
        const taskCell = document.createElement('td');
        const quantityCell = document.createElement('td');

        idCell.textContent = task.id;
        taskCell.textContent = task.task;
        quantityCell.textContent = task.quantity;

        row.appendChild(idCell);
        row.appendChild(taskCell);
        row.appendChild(quantityCell);

        return row;
    }

    async function fetchAndDisplayTasks() {
        try {
            const response = await fetch('/api/tasks');
            if (response.ok) {
                const tasks = await response.json();
                taskTableBody.innerHTML = ''; // Clear previous table content
                tasks.forEach(task => {
                    const row = createTableRow(task);
                    taskTableBody.appendChild(row);
                });
            } else {
                console.error('Error fetching tasks:', response.statusText);
            }
        } catch (error) {
            console.error('Error fetching tasks:', error);
        }
    }

    deleteDatabaseBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('/api/tasks', {
                method: 'DELETE'
            });

            if (response.ok) {
                taskTableBody.innerHTML = ''; // Clear the table
                console.log('Database deleted successfully.');
            } else {
                console.error('Error deleting database:', response.statusText);
            }
        } catch (error) {
            console.error('Error deleting database:', error);
        }
    });

    // Initial fetch and display when the page loads
    taskForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const taskText = taskInput.value.trim();
        const taskTextint = taskInputint.value.trim();
        if (taskText !== '' && taskTextint !=='') {
            try {
                const response = await fetch('/api/tasks', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ task: taskText , quantity: taskTextint })
                });

                if (response.ok) {
                    addTask(taskText);
                    addTask(taskTextint);
                    taskInput.value = '';
                    taskInputint.value='';
                } else {
                    console.error('Error adding task:', response.statusText);
                }
            } catch (error) {
                console.error('Error adding task:', error);
            }
        }
    });

    function addTask(taskText) {
        const li = document.createElement('li');
        li.textContent = taskText;
        taskList.appendChild(li);
    }
    
});
