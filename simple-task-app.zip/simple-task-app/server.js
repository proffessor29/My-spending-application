const express = require('express');
const mysql = require('mysql');
const path = require('path');

const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const db = mysql.createConnection({
    host: 'localhost',          // Change to your MySQL host
    user: 'root',       // Change to your MySQL username
    password: 'password',   // Change to your MySQL password
    database: 'data-table'    // Change to your MySQL database name
});

db.connect((err) => {
    if (err) {
        console.error('Database connection error:', err);
    } else {
        console.log('Connected to the database.');
        db.query(`
            CREATE TABLE IF NOT EXISTS tasks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                task TEXT , quantity INT
            )
        `, (err) => {
            if (err) {
                console.error('Table creation error:', err);
            }
        });
    }
});

app.post('/api/tasks', (req, res) => {
    const taskText = req.body.task;
    const taskTextint = req.body.quantity ;
    if (taskText) {
        db.query('INSERT INTO tasks (task , quantity) VALUES (?,?)', [taskText , taskTextint], (err, result) => {
            if (err) {
                console.error('Database insertion error:', err);
                res.status(500).json({ error: 'Database error' });
            } else {
                console.log('Task added successfully, ID:', result.insertId);
                res.json({ message: 'Task added successfully' });
            }
        });
    } else {
        res.status(400).json({ error: 'Task text is required' });
    }
});



app.get('/api/tasks', (req, res) => {
    db.query('SELECT * FROM tasks', (err, rows) => {
        if (err) {
            res.status(500).json({ error: 'Database error' });
        } else {
            res.json(rows);
        }
    });
});

app.delete('/api/tasks', (req, res) => {
    db.query('DELETE FROM tasks', (err) => {
        if (err) {
            console.error('Database deletion error:', err);
            res.status(500).json({ error: 'Database error' });
        } else {
            console.log('Database deleted successfully.');
            res.json({ message: 'Database deleted successfully' });
        }
    });
});


app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
